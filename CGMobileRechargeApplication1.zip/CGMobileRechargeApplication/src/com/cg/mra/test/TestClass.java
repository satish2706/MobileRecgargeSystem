package com.cg.mra.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.InvalidMobileNumber;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

import junit.framework.Assert;

public class TestClass {
    public static AccountService accountService ;
		
	    	  
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	
	accountService =new AccountServiceImpl();
	}

	@Before
	public void setUp() throws Exception {
	
	Account account=new Account("9010210131","Prepaid", "Vaishali", 200);
		
	}
		
	
	
	@Test
    public void testMobileNumberForValidData()  {
     String expectedAns="9010210131";
     double actualAns=accountService.rechargeAccount("9010210131", (Double) null);
        Assert.assertEquals(expectedAns, actualAns);
    }
	
	
	
	
	
	
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		accountService=null;
	}


	@After
	public void tearDown() throws Exception {
	
	}


      }
