package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.InvalidMobileNumber;

public class AccountServiceImpl implements AccountService{

	AccountDao accountdao=new AccountDaoImpl();
	
	
	@Override
	public Account getAccountDetails(String mobileNo)throws InvalidMobileNumber {
				
		if(mobileNo.length()<10) 
 			
 		throw new InvalidMobileNumber("Error: Given Number doesn't exist");	
		
				
		
 				
		return accountdao.getAccountDetails(mobileNo);
	}

	
	
	@Override
	public double rechargeAccount(String mobileno, double rechargeAmount) {
		
		return accountdao.rechargeAccount(mobileno, rechargeAmount);
	}

}
